"""
M3G Importer for Blender
Imports JSR-184 M3G files directly into Blender as mesh objects with materials/textures.

Install: Edit > Preferences > Add-ons > Install > select this folder (zip) or __init__.py
"""

bl_info = {
    "name":        "M3G Importer",
    "author":      "m3g_to_obj port",
    "version":     (1, 0, 0),
    "blender":     (3, 0, 0),
    "location":    "File > Import > M3G (.m3g)",
    "description": "Import JSR-184 M3G mobile 3D graphics files",
    "category":    "Import-Export",
}

import bpy
import os
import struct
import math
import zlib
import tempfile

from bpy.props import StringProperty, BoolProperty
from bpy_extras.io_utils import ImportHelper


# ---------------------------------------------------------------------------
# Object type constants
# ---------------------------------------------------------------------------
OBJTYPE_HEADER               = 0
OBJTYPE_ANIMATION_CONTROLLER = 1
OBJTYPE_ANIMATION_TRACK      = 2
OBJTYPE_APPEARANCE           = 3
OBJTYPE_BACKGROUND           = 4
OBJTYPE_CAMERA               = 5
OBJTYPE_FOG                  = 7
OBJTYPE_POLYGON_MODE         = 8
OBJTYPE_GROUP                = 9
OBJTYPE_IMAGE2D              = 10
OBJTYPE_TRIANGLE_STRIP_ARRAY = 11
OBJTYPE_LIGHT                = 12
OBJTYPE_MATERIAL             = 13
OBJTYPE_MESH                 = 14
OBJTYPE_SKINNED_MESH         = 16
OBJTYPE_TEXTURE2D            = 17
OBJTYPE_KEYFRAME_SEQUENCE    = 19
OBJTYPE_VERTEX_ARRAY         = 20
OBJTYPE_VERTEX_BUFFER        = 21
OBJTYPE_WORLD                = 22
OBJTYPE_EXTERNAL_REF         = 0xFF

M3G_MAGIC = bytes([0xAB,0x4A,0x53,0x52,0x31,0x38,0x34,0xBB,0x0D,0x0A,0x1A,0x0A])


# ---------------------------------------------------------------------------
# Byte reader
# ---------------------------------------------------------------------------
class ByteReader:
    def __init__(self, data):
        self.data = data
        self.pos  = 0

    def remaining(self):  return len(self.data) - self.pos
    def read(self, n):
        b = self.data[self.pos:self.pos+n]
        self.pos += n
        return b
    def unpack(self, fmt):
        sz = struct.calcsize(fmt)
        return struct.unpack(fmt, self.read(sz))
    def u8(self):    return self.unpack('<B')[0]
    def u16(self):   return self.unpack('<H')[0]
    def u32(self):   return self.unpack('<I')[0]
    def i32(self):   return self.unpack('<i')[0]
    def f32(self):   return self.unpack('<f')[0]
    def bool8(self): return self.u8() != 0
    def utf8z(self):
        buf = bytearray()
        while True:
            b = self.read(1)
            if b == b'\x00': break
            buf += b
        return buf.decode('utf-8', errors='replace')


# ---------------------------------------------------------------------------
# Parsed object stubs
# ---------------------------------------------------------------------------
class Obj:
    def __init__(self, t, idx):
        self.object_type  = t
        self.object_index = idx

class Obj3D(Obj):
    pass

class Transformable(Obj3D):
    has_component_transform = False
    translation = (0.0, 0.0, 0.0)
    scale_xyz   = (1.0, 1.0, 1.0)
    orient_angle= 0.0
    orient_axis = (0.0, 0.0, 1.0)
    has_general_transform = False
    matrix = None

class Node(Transformable):
    enable_rendering = True
    enable_picking   = True
    alpha_factor     = 255
    scope            = 0xFFFFFFFF
    has_alignment    = False


# ---------------------------------------------------------------------------
# Base readers
# ---------------------------------------------------------------------------
def read_obj3d(r, obj):
    obj.user_id   = r.u32()
    n = r.u32()
    obj.anim_refs = [r.u32() for _ in range(n)]
    np_ = r.u32()
    for _ in range(np_):
        r.u32()
        r.read(r.u32())

def read_transformable(r, obj):
    read_obj3d(r, obj)
    obj.has_component_transform = r.bool8()
    if obj.has_component_transform:
        obj.translation  = r.unpack('<3f')
        obj.scale_xyz    = r.unpack('<3f')
        obj.orient_angle = r.f32()
        obj.orient_axis  = r.unpack('<3f')
    obj.has_general_transform = r.bool8()
    if obj.has_general_transform:
        obj.matrix = r.unpack('<16f')

def read_node(r, obj):
    read_transformable(r, obj)
    obj.enable_rendering = r.bool8()
    obj.enable_picking   = r.bool8()
    obj.alpha_factor     = r.u8()
    obj.scope            = r.u32()
    obj.has_alignment    = r.bool8()
    if obj.has_alignment:
        r.u8(); r.u8()
        r.u32(); r.u32()


# ---------------------------------------------------------------------------
# Object parsers
# ---------------------------------------------------------------------------
def parse_header(r, idx, _dlen, _start):
    o = Obj(OBJTYPE_HEADER, idx)
    o.version_major       = r.u8()
    o.version_minor       = r.u8()
    o.has_external_refs   = r.bool8()
    o.total_file_size     = r.u32()
    o.approx_content_size = r.u32()
    o.authoring_field     = r.utf8z()
    return o

def parse_vertex_array(r, idx, _dlen, _start):
    o = Obj3D(OBJTYPE_VERTEX_ARRAY, idx)
    read_obj3d(r, o)
    o.component_size  = r.u8()
    o.component_count = r.u8()
    o.encoding        = r.u8()
    o.vertex_count    = r.u16()
    fmt = 'b' if o.component_size == 1 else 'h'
    total = o.vertex_count * o.component_count
    o.components = list(r.unpack(f'<{total}{fmt}'))
    return o

def parse_vertex_buffer(r, idx, _dlen, _start):
    o = Obj3D(OBJTYPE_VERTEX_BUFFER, idx)
    read_obj3d(r, o)
    o.default_color  = r.unpack('<4B')
    o.positions_ref  = r.u32()
    o.position_bias  = r.unpack('<3f')
    o.position_scale = r.f32()
    o.normals_ref    = r.u32()
    o.colors_ref     = r.u32()
    tex_count        = r.u32()
    o.texcoord_refs  = []
    for _ in range(tex_count):
        ref   = r.u32()
        bias  = r.unpack('<3f')
        scale = r.f32()
        o.texcoord_refs.append({'ref': ref, 'bias': bias, 'scale': scale})
    return o

def parse_tsa(r, idx, dlen, start):
    o = Obj3D(OBJTYPE_TRIANGLE_STRIP_ARRAY, idx)
    read_obj3d(r, o)

    encoding = r.u8()
    if encoding == 128:
        implicit_count = r.u32()
        o.indices = list(range(implicit_count))
    elif encoding == 0:
        n = r.u32()
        o.indices = [r.u32() for _ in range(n)]
    elif encoding in (1, 129):
        n = r.u32()
        o.indices = [r.u8() for _ in range(n)]
    elif encoding in (2, 130):
        n = r.u32()
        o.indices = [r.u16() for _ in range(n)]
    else:
        n = r.u32()
        o.indices = [r.u8() for _ in range(n)]

    strip_count = r.u32()
    o.strip_lengths = [r.u32() for _ in range(strip_count)]
    return o

def parse_appearance(r, idx, _dlen, _start):
    o = Obj3D(OBJTYPE_APPEARANCE, idx)
    read_obj3d(r, o)
    o.layer              = r.u8()
    o.compound_index_ref = r.u32()
    o.fog_ref            = r.u32()
    o.polygon_mode_ref   = r.u32()
    o.material_ref       = r.u32()
    tex_count            = r.u32()
    o.texture_refs       = [r.u32() for _ in range(tex_count)]
    return o

def parse_material(r, idx, _dlen, _start):
    o = Obj3D(OBJTYPE_MATERIAL, idx)
    read_obj3d(r, o)
    o.ambient_color  = r.unpack('<3B')
    o.diffuse_color  = r.unpack('<4B')
    o.emissive_color = r.unpack('<3B')
    o.specular_color = r.unpack('<3B')
    o.shininess      = r.f32()
    o.vertex_color_tracking = r.bool8()
    return o

def parse_mesh(r, idx, _dlen, _start):
    o = Node(OBJTYPE_MESH, idx)
    read_node(r, o)
    o.vertex_buffer_ref = r.u32()
    submesh_count       = r.u32()
    o.submeshes = []
    for _ in range(submesh_count):
        o.submeshes.append({'index_buffer': r.u32(), 'appearance': r.u32()})
    return o

def parse_skinned_mesh(r, idx, _dlen, _start):
    o = Node(OBJTYPE_SKINNED_MESH, idx)
    read_node(r, o)
    o.vertex_buffer_ref = r.u32()
    submesh_count       = r.u32()
    o.submeshes = []
    for _ in range(submesh_count):
        o.submeshes.append({'index_buffer': r.u32(), 'appearance': r.u32()})
    o.skeleton_ref = r.u32()
    bone_count     = r.u32()
    o.bones = []
    for _ in range(bone_count):
        o.bones.append({
            'node':  r.u32(), 'first': r.u32(),
            'count': r.u32(), 'weight': r.i32()
        })
    return o

def parse_group(r, idx, _dlen, _start):
    o = Node(OBJTYPE_GROUP, idx)
    read_node(r, o)
    o.children = [r.u32() for _ in range(r.u32())]
    return o

def parse_world(r, idx, _dlen, _start):
    o = Node(OBJTYPE_WORLD, idx)
    read_node(r, o)
    o.children          = [r.u32() for _ in range(r.u32())]
    o.active_camera_ref = r.u32()
    o.background_ref    = r.u32()
    return o

def parse_image2d(r, idx, dlen, start):
    o = Obj3D(OBJTYPE_IMAGE2D, idx)
    read_obj3d(r, o)
    o.format     = r.u8()
    o.is_mutable = r.bool8()
    o.width      = r.u32()
    o.height     = r.u32()
    o.pixels     = None
    if not o.is_mutable:
        bpp_map = {96: 1, 97: 1, 98: 2, 99: 3, 100: 4}
        bpp = bpp_map.get(o.format, 4)
        pal_byte_count = r.u32()
        palette        = r.read(pal_byte_count)
        pixel_count    = r.u32()
        indices        = r.read(pixel_count)
        out = bytearray(pixel_count * bpp)
        for i, idx_val in enumerate(indices):
            src = idx_val * bpp
            out[i*bpp:(i+1)*bpp] = palette[src:src+bpp]
        o.pixels = bytes(out)
    return o

def parse_texture2d(r, idx, dlen, start):
    o = Obj3D(OBJTYPE_TEXTURE2D, idx)
    read_obj3d(r, o)
    has_comp = r.bool8()
    if has_comp:
        r.unpack('<3f'); r.unpack('<3f'); r.f32(); r.unpack('<3f')
    has_gen = r.bool8()
    if has_gen:
        r.unpack('<16f')
    o.image_ref    = r.u32()
    o.blend_color  = r.unpack('<3B')
    o.blending     = r.u8()
    o.wrapping_s   = r.u8()
    o.wrapping_t   = r.u8()
    o.level_filter = r.u8()
    o.image_filter = r.u8()
    return o

def parse_external_ref(r, idx, dlen, start):
    o = Obj(OBJTYPE_EXTERNAL_REF, idx)
    o.uri = r.utf8z()
    return o

PARSERS = {
    OBJTYPE_HEADER:               parse_header,
    OBJTYPE_VERTEX_ARRAY:         parse_vertex_array,
    OBJTYPE_VERTEX_BUFFER:        parse_vertex_buffer,
    OBJTYPE_TRIANGLE_STRIP_ARRAY: parse_tsa,
    OBJTYPE_APPEARANCE:           parse_appearance,
    OBJTYPE_MATERIAL:             parse_material,
    OBJTYPE_MESH:                 parse_mesh,
    OBJTYPE_SKINNED_MESH:         parse_skinned_mesh,
    OBJTYPE_GROUP:                parse_group,
    OBJTYPE_WORLD:                parse_world,
    OBJTYPE_IMAGE2D:              parse_image2d,
    OBJTYPE_TEXTURE2D:            parse_texture2d,
    OBJTYPE_EXTERNAL_REF:         parse_external_ref,
}


# ---------------------------------------------------------------------------
# File parser
# ---------------------------------------------------------------------------
def parse_m3g(filepath):
    with open(filepath, 'rb') as f:
        raw = f.read()

    r = ByteReader(raw)
    magic = r.read(12)
    if magic != M3G_MAGIC:
        raise ValueError("Not a valid M3G file (bad magic bytes)")

    objects  = {}
    next_idx = [1]

    def parse_section(data):
        sr = ByteReader(data)
        while sr.remaining() >= 5:
            obj_type = sr.u8()
            data_len = sr.u32()
            start    = sr.pos
            end      = start + data_len
            idx      = next_idx[0]
            next_idx[0] += 1
            parser = PARSERS.get(obj_type)
            if parser:
                try:
                    obj = parser(sr, idx, data_len, start)
                    if obj is not None:
                        objects[idx] = obj
                except Exception as e:
                    print(f"  [M3G] Warning: failed to parse object type={obj_type} idx={idx}: {e}")
            sr.pos = end

    while r.remaining() >= 13:
        compression = r.u8()
        total_len   = r.u32()
        uncomp_len  = r.u32()
        payload_len = total_len - 13
        payload     = r.read(payload_len)
        _checksum   = r.u32()
        if compression == 1:
            payload = zlib.decompress(payload)
        elif compression != 0:
            continue
        parse_section(payload)

    return objects


# ---------------------------------------------------------------------------
# PNG writer (no PIL required)
# ---------------------------------------------------------------------------
def write_png(width, height, pixel_bytes, path, img_format=100):
    import zlib as _zlib
    import struct as _s

    def _chunk(tag, data):
        c = _s.pack('>I', len(data)) + tag + data
        return c + _s.pack('>I', _zlib.crc32(c[4:]) & 0xFFFFFFFF)

    fmt_map = {96: (0, 1), 97: (0, 1), 98: (4, 2), 99: (2, 3), 100: (6, 4)}
    color_type, bpp = fmt_map.get(img_format, (6, 4))

    expected = width * height * bpp
    if len(pixel_bytes) < expected:
        actual_bpp = len(pixel_bytes) // (width * height)
        if actual_bpp in (3, 4):
            bpp = actual_bpp
            color_type = 2 if bpp == 3 else 6

    ihdr = _s.pack('>IIBBBBB', width, height, 8, color_type, 0, 0, 0)
    raw = bytearray()
    row_bytes = width * bpp
    for y in range(height):
        raw.append(0)
        raw.extend(pixel_bytes[y * row_bytes: (y + 1) * row_bytes])

    idat_data = _zlib.compress(bytes(raw), 9)
    with open(path, 'wb') as f:
        f.write(b'\x89PNG\r\n\x1a\n')
        f.write(_chunk(b'IHDR', ihdr))
        f.write(_chunk(b'IDAT', idat_data))
        f.write(_chunk(b'IEND', b''))


# ---------------------------------------------------------------------------
# Geometry helpers
# ---------------------------------------------------------------------------
def decode_array(va, bias, scale):
    nc    = va.component_count
    comps = va.components
    out   = []
    for i in range(0, len(comps), nc):
        group = comps[i:i+nc]
        if len(bias) >= nc:
            out.append(tuple(group[j] * scale + bias[j] for j in range(nc)))
        else:
            out.append(tuple(v * scale for v in group))
    return out

def strips_to_triangles(indices, strip_lengths):
    tris = []
    pos  = 0
    for length in strip_lengths:
        strip = indices[pos:pos+length]
        pos  += length
        for i in range(len(strip) - 2):
            a, b, c = strip[i], strip[i+1], strip[i+2]
            if i % 2 == 0:
                tris.append((a, b, c))
            else:
                tris.append((b, a, c))
    return tris

def mat3x3_mul_vec(m16, v3):
    x, y, z = v3
    return (
        m16[0]*x + m16[4]*y + m16[8]*z,
        m16[1]*x + m16[5]*y + m16[9]*z,
        m16[2]*x + m16[6]*y + m16[10]*z,
    )

def mat4_mul_point(m16, p3):
    x, y, z = p3
    w = m16[3]*x + m16[7]*y + m16[11]*z + m16[15]
    if abs(w) < 1e-10: w = 1.0
    return (
        (m16[0]*x + m16[4]*y + m16[8]*z  + m16[12]) / w,
        (m16[1]*x + m16[5]*y + m16[9]*z  + m16[13]) / w,
        (m16[2]*x + m16[6]*y + m16[10]*z + m16[14]) / w,
    )

def mat4_mul_mat4(a, b):
    out = [0.0] * 16
    for col in range(4):
        for row in range(4):
            out[col*4+row] = sum(a[k*4+row] * b[col*4+k] for k in range(4))
    return out

def node_world_matrix(node, objects):
    chain = [node]
    parent_map = {}
    for obj in objects.values():
        if hasattr(obj, 'children'):
            for child_ref in obj.children:
                parent_map[child_ref] = obj.object_index
    current_idx = node.object_index
    while current_idx in parent_map:
        parent_idx = parent_map[current_idx]
        parent = objects.get(parent_idx)
        if parent is None:
            break
        chain.append(parent)
        current_idx = parent_idx
    m = [0.0]*16
    m[0] = m[5] = m[10] = m[15] = 1.0
    for ancestor in reversed(chain):
        local = node_matrix(ancestor)
        m = mat4_mul_mat4(m, local)
    return m

def node_matrix(node):
    if node.has_general_transform and node.matrix:
        return list(node.matrix)
    m = [0.0]*16
    m[0] = m[5] = m[10] = m[15] = 1.0
    if node.has_component_transform:
        tx, ty, tz = node.translation
        sx, sy, sz = node.scale_xyz
        angle      = node.orient_angle
        ax, ay, az = node.orient_axis
        length = math.sqrt(ax*ax + ay*ay + az*az)
        if length > 1e-6:
            ax /= length; ay /= length; az /= length
        c, s = math.cos(angle), math.sin(angle)
        t = 1.0 - c
        R = [
            t*ax*ax+c,    t*ax*ay-s*az, t*ax*az+s*ay, 0,
            t*ax*ay+s*az, t*ay*ay+c,    t*ay*az-s*ax, 0,
            t*ax*az-s*ay, t*ay*az+s*ax, t*az*az+c,    0,
            0,            0,            0,            1,
        ]
        m = [
            R[0]*sx, R[1]*sx, R[2]*sx,  0,
            R[4]*sy, R[5]*sy, R[6]*sy,  0,
            R[8]*sz, R[9]*sz, R[10]*sz, 0,
            tx,      ty,      tz,       1,
        ]
    return m


# ---------------------------------------------------------------------------
# Blender mesh builder
# ---------------------------------------------------------------------------
def build_blender_objects(objects, m3g_path, use_y_up):
    """Main importer: parse M3G objects and create Blender meshes/materials."""
    import bpy

    get          = lambda ref: objects.get(ref) if ref else None
    m3g_dir      = os.path.dirname(os.path.abspath(m3g_path))
    # Prefix for texture PNGs — prevents conflicts when multiple M3G files
    # live in the same folder and export textures with overlapping indices.
    m3g_stem     = os.path.splitext(os.path.basename(m3g_path))[0]
    tex_dir      = m3g_dir   # textures written next to the M3G file

    # Cache: image index -> bpy.types.Image (so we don't reload duplicates)
    blender_images = {}
    # Cache: material name -> bpy.types.Material
    blender_mats   = {}

    def get_or_create_image(img, m3g_stem_prefix):
        """Return a bpy.types.Image, writing PNG to disk if needed."""
        key = img.object_index

        if key in blender_images:
            return blender_images[key]

        # --- Embedded pixel data (Image2D) ---
        if img.object_type == OBJTYPE_IMAGE2D and img.pixels:
            # Prefix with M3G filename to avoid clashes with other models
            png_name = f"{m3g_stem_prefix}_Image_{img.object_index}.png"
            png_path = os.path.join(tex_dir, png_name)
            if not os.path.exists(png_path):
                try:
                    write_png(img.width, img.height, img.pixels, png_path,
                              img_format=img.format)
                    print(f"  [M3G] Wrote texture: {png_path}")
                except Exception as e:
                    print(f"  [M3G] Warning: could not write PNG: {e}")
                    return None
            bl_img = bpy.data.images.load(png_path, check_existing=True)
            blender_images[key] = bl_img
            return bl_img

        # --- ExternalRef ---
        if img.object_type == OBJTYPE_EXTERNAL_REF:
            uri     = img.uri
            uri_rel = uri.lstrip('/\\')
            candidates = [
                os.path.join(m3g_dir, uri_rel),
                os.path.join(m3g_dir, os.path.basename(uri_rel)),
            ]
            found = next((p for p in candidates if os.path.exists(p)), None)
            if found:
                bl_img = bpy.data.images.load(found, check_existing=True)
                blender_images[key] = bl_img
                return bl_img
            else:
                print(f"  [M3G] Warning: external texture not found: {uri!r}")
                return None

        return None

    def make_material(mat_name, mat_parsed, tex_image, has_alpha):
        """Build (or reuse) a Blender material with nodes."""
        if mat_name in blender_mats:
            return blender_mats[mat_name]

        mat = bpy.data.materials.new(name=mat_name)
        mat.use_nodes = True
        nodes = mat.node_tree.nodes
        links = mat.node_tree.links
        nodes.clear()

        bsdf = nodes.new('ShaderNodeBsdfPrincipled')
        bsdf.location = (0, 0)
        out  = nodes.new('ShaderNodeOutputMaterial')
        out.location  = (300, 0)
        links.new(bsdf.outputs['BSDF'], out.inputs['Surface'])

        if mat_parsed and mat_parsed.object_type == OBJTYPE_MATERIAL:
            r2, g2, b2, a2 = (c / 255.0 for c in mat_parsed.diffuse_color)
            er, eg, eb     = (c / 255.0 for c in mat_parsed.emissive_color)
            bsdf.inputs['Base Color'].default_value = (r2, g2, b2, 1.0)
            bsdf.inputs['Alpha'].default_value      = a2
            if hasattr(bsdf.inputs, 'Emission Color'):
                bsdf.inputs['Emission Color'].default_value = (er, eg, eb, 1.0)
            elif 'Emission' in bsdf.inputs:
                bsdf.inputs['Emission'].default_value = (er, eg, eb, 1.0)
            if a2 < 1.0 or has_alpha:
                mat.blend_method = 'BLEND'

        if tex_image:
            tex_node = nodes.new('ShaderNodeTexImage')
            tex_node.image    = tex_image
            tex_node.location = (-300, 0)
            links.new(tex_node.outputs['Color'], bsdf.inputs['Base Color'])
            if has_alpha:
                links.new(tex_node.outputs['Alpha'], bsdf.inputs['Alpha'])
                mat.blend_method = 'BLEND'

        blender_mats[mat_name] = mat
        return mat

    # -------------------------------------------------------------------
    # Main loop over mesh objects
    # -------------------------------------------------------------------
    mesh_objects = [o for o in objects.values()
                    if o.object_type in (OBJTYPE_MESH, OBJTYPE_SKINNED_MESH)]

    if not mesh_objects:
        print("  [M3G] No mesh objects found.")
        return

    created_objects = []

    for mesh_obj in mesh_objects:
        vb = get(getattr(mesh_obj, 'vertex_buffer_ref', 0))
        if vb is None or vb.object_type != OBJTYPE_VERTEX_BUFFER:
            print(f"  [M3G] Mesh idx={mesh_obj.object_index}: missing VertexBuffer, skipped")
            continue

        pos_va = get(vb.positions_ref)
        if pos_va is None or pos_va.object_type != OBJTYPE_VERTEX_ARRAY:
            print(f"  [M3G] Mesh idx={mesh_obj.object_index}: missing position VertexArray, skipped")
            continue

        positions = decode_array(pos_va, vb.position_bias, vb.position_scale)

        # Normals
        normals = []
        if vb.normals_ref:
            nrm_va = get(vb.normals_ref)
            if nrm_va and nrm_va.object_type == OBJTYPE_VERTEX_ARRAY:
                normals = decode_array(nrm_va, [0.0, 0.0, 0.0], 1.0 / 127.0)

        # UVs (first layer)
        uvs = []
        if vb.texcoord_refs:
            uv_entry = vb.texcoord_refs[0]
            uv_va = get(uv_entry['ref'])
            if uv_va and uv_va.object_type == OBJTYPE_VERTEX_ARRAY:
                raw_uvs = decode_array(uv_va, list(uv_entry['bias']), uv_entry['scale'])
                uvs = [(u, 1.0 - v) for (u, v) in raw_uvs]

        # World transform
        m = node_world_matrix(mesh_obj, objects)
        positions_w = [mat4_mul_point(m, p) for p in positions]
        normals_w   = [mat3x3_mul_vec(m, n) for n in normals]

        # Coordinate system conversion: M3G is Y-up; Blender is Z-up
        if use_y_up:
            # Keep as-is (import as M3G Y-up)
            verts = [(x, y, z) for (x, y, z) in positions_w]
        else:
            # Swap Y/Z to convert to Blender Z-up
            verts = [(x, -z, y) for (x, y, z) in positions_w]

        has_normals = len(normals_w) == len(positions_w)
        has_uvs     = len(uvs)       == len(positions_w)

        # Collect all triangles from all submeshes
        all_tris   = []
        tri_mat_id = []  # per-triangle material index

        mat_slots = []   # list of bpy.types.Material for this mesh

        for sub_idx, sub in enumerate(mesh_obj.submeshes):
            ib = get(sub['index_buffer'])
            if (ib is None or ib.object_type != OBJTYPE_TRIANGLE_STRIP_ARRAY
                    or not hasattr(ib, 'indices') or not hasattr(ib, 'strip_lengths')):
                print(f"    [M3G] Submesh {sub_idx}: bad IndexBuffer, skipped")
                continue

            triangles = strips_to_triangles(ib.indices, ib.strip_lengths)

            # --- Material ---
            app = get(sub['appearance'])
            bl_mat = None
            if app and app.object_type == OBJTYPE_APPEARANCE:
                tex_image  = None
                has_alpha  = False
                tex_suffix = ""

                if app.texture_refs:
                    tex2d = get(app.texture_refs[0])
                    if tex2d and tex2d.object_type == OBJTYPE_TEXTURE2D:
                        img = get(tex2d.image_ref)
                        if img:
                            tex_image = get_or_create_image(img, m3g_stem)
                            if img.object_type == OBJTYPE_IMAGE2D:
                                tex_suffix = f"_Tex{img.object_index}"
                                has_alpha  = img.format in (98, 100)  # LUM_ALPHA or RGBA
                            elif img.object_type == OBJTYPE_EXTERNAL_REF:
                                tex_suffix = f"_Ext{img.object_index}"

                mat_parsed = get(app.material_ref)
                if mat_parsed and mat_parsed.object_type == OBJTYPE_MATERIAL:
                    mat_name = f"M3G_{m3g_stem}_Mat_{mat_parsed.object_index}{tex_suffix}"
                elif tex_image:
                    mat_name = f"M3G_{m3g_stem}_Tex{tex_suffix}"
                else:
                    mat_name = f"M3G_{m3g_stem}_Default"

                bl_mat = make_material(mat_name, mat_parsed, tex_image, has_alpha)

            mat_slot_idx = len(mat_slots)
            mat_slots.append(bl_mat)

            for tri in triangles:
                all_tris.append(tri)
                tri_mat_id.append(mat_slot_idx)

        if not all_tris:
            continue

        # Build Blender mesh
        mesh_name = f"M3G_Mesh_{mesh_obj.object_index}"
        bl_mesh = bpy.data.meshes.new(mesh_name)
        bl_mesh.from_pydata(verts, [], all_tris)
        bl_mesh.update()

        # UV map
        if has_uvs:
            uv_layer = bl_mesh.uv_layers.new(name="UVMap")
            for poly in bl_mesh.polygons:
                for loop_idx in poly.loop_indices:
                    vi = bl_mesh.loops[loop_idx].vertex_index
                    uv_layer.data[loop_idx].uv = uvs[vi]

        # Normals
        if has_normals:
            bl_mesh.use_auto_smooth = True
            bl_mesh.normals_split_custom_set_from_vertices(
                [normals_w[i] for i in range(len(verts))]
            )

        # Assign materials & per-face material indices
        for bl_mat in mat_slots:
            if bl_mat:
                bl_mesh.materials.append(bl_mat)
            else:
                bl_mesh.materials.append(None)

        for poly, mat_id in zip(bl_mesh.polygons, tri_mat_id):
            poly.material_index = mat_id

        bl_obj = bpy.data.objects.new(mesh_name, bl_mesh)
        bpy.context.collection.objects.link(bl_obj)
        created_objects.append(bl_obj)

    # Select all newly created objects
    for obj in created_objects:
        obj.select_set(True)

    if created_objects:
        bpy.context.view_layer.objects.active = created_objects[0]

    print(f"  [M3G] Imported {len(created_objects)} mesh object(s) from {m3g_path}")
    return created_objects


# ---------------------------------------------------------------------------
# Operator
# ---------------------------------------------------------------------------
class IMPORT_OT_m3g(bpy.types.Operator, ImportHelper):
    bl_idname      = "import_scene.m3g"
    bl_label       = "Import M3G"
    bl_description = "Import a JSR-184 M3G mobile 3D file"
    bl_options     = {'REGISTER', 'UNDO'}

    filename_ext = ".m3g"
    filter_glob: StringProperty(default="*.m3g", options={'HIDDEN'})

    use_y_up: BoolProperty(
        name="Keep M3G Y-up",
        description="Import without axis conversion (M3G is Y-up; disable to convert to Blender Z-up)",
        default=False,
    )

    def execute(self, context):
        try:
            objects = parse_m3g(self.filepath)
            build_blender_objects(objects, self.filepath, self.use_y_up)
        except Exception as e:
            self.report({'ERROR'}, f"M3G import failed: {e}")
            import traceback
            traceback.print_exc()
            return {'CANCELLED'}
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "use_y_up")


# ---------------------------------------------------------------------------
# Menu entry
# ---------------------------------------------------------------------------
def menu_func_import(self, context):
    self.layout.operator(IMPORT_OT_m3g.bl_idname, text="M3G (.m3g)")


# ---------------------------------------------------------------------------
# Register
# ---------------------------------------------------------------------------
def register():
    bpy.utils.register_class(IMPORT_OT_m3g)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)

def unregister():
    bpy.utils.unregister_class(IMPORT_OT_m3g)
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)

if __name__ == "__main__":
    register()
